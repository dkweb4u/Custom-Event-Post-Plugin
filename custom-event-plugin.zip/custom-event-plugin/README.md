Requirments:

> Advanced Custom Fields(ACF) Plugin for Custom fields

Installation:

There are Two Files

> Our Event Plugin 

> custom-field.json file  contains ACF Custom field  (date,  location, organizer) 

Step 1: Install	Advanced Custom Fields(ACF) Plugin

Step 2: Install Our Event Plugin 

Step 3: ACF Plugin > More > Tools > Import > upload custom-field.json file

Working Process

> Our Plugin Contains 3 options

* All Events - Shows all Created Events

* Add New Event - Create New Events

* Settings - Getting Short code options and settings

In Settings Page Get Shortcode of select options

-> Posts Per page - Default is 5 | min:1| max:10
-> Order By - Default is Asc | Desc
-> Current Event - Default is Upcoming | Old | All
-> Based your selection shortcode generated

> button to copy the shortcode and use anywhere is website




